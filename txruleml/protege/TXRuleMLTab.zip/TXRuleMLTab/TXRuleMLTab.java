
/**
 * User: student
 * Date: Nov 3, 2002
 * Time: 11:04:38 AM
 */
package TXRuleMLTab;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;
import edu.stanford.smi.protege.widget.*;





public class TXRuleMLTab extends AbstractTabWidget {
    private JButton buttonInport;
    private JButton buttonExport;
    private JTextPane textPane;
    private Document doc;
    private JFileChooser fileChooser;
    private JTextArea history;
    private OntologyConnection ontoConnection;
    private TXRuleMLConnection rulemlConnection;
    private myFileFilter rulemlFilter;

    // startup code
    public void initialize() {
        // initialize the tab text
        setLabel("TaXonomic RuleML Convertor");

        // create the button inport
        buttonInport = new JButton("  <<  I M P O R T  <<  ");
        buttonInport.addActionListener(new ActionListener() {
            // called when the button is pressed
            public void actionPerformed(ActionEvent event) {
                actionImport();
            }
        });

        // create the button export
        buttonExport = new JButton("  >>  E X P O R T  >>  ");
        buttonExport.addActionListener(new ActionListener() {
            // called when the button is pressed
            public void actionPerformed(ActionEvent event) {
                actionExport();
            }
        });


        JPanel panelButton = new JPanel();
        panelButton.add(buttonInport,BorderLayout.WEST);
        panelButton.add(buttonExport);//,BorderLayout.SOUTH);


        history = new JTextArea(3,45);
        history.setMargin(new Insets(5,5,5,5));
        history.setEditable(false);
        JScrollPane historyScrollPane = new JScrollPane(history);
        historyScrollPane.setBorder(BorderFactory.createCompoundBorder(
                       BorderFactory.createTitledBorder(" Action history :"),
                       BorderFactory.createEmptyBorder(5,5,5,5)));
        historyScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panelButton.add(historyScrollPane,BorderLayout.EAST);


        // create the output text field
        textPane = new JTextPane();
        initStylesForTextPane();
        initTextPane();
        doc = textPane.getDocument();
        textPane.setEditable(false);

        JScrollPane panelTXRuleMLFile = new JScrollPane(textPane);
        panelTXRuleMLFile.setBorder(BorderFactory.createCompoundBorder(
                       BorderFactory.createTitledBorder(" The TaXonomic RuleML File :"),
                       BorderFactory.createEmptyBorder(5,5,5,5)));
        panelTXRuleMLFile.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // add the components to the tab widget
    	setLayout(new BorderLayout());
    	add(panelButton,BorderLayout.NORTH);
        add(panelTXRuleMLFile);

        //field.setHorizontalAlignment(JTextField.RIGHT);

        //Create a file chooser

        fileChooser = new JFileChooser();
        rulemlFilter = new myFileFilter("ruleml", "TaXonomic RuleML files");

        fileChooser.resetChoosableFileFilters();
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(rulemlFilter);
        fileChooser.setFileFilter(rulemlFilter);

        rulemlFilter.setExtensionListInDescription(true);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);


        ontoConnection=  new OntologyConnection(this.getKnowledgeBase());
        rulemlConnection = new TXRuleMLConnection(ontoConnection,this);
    }





    protected void initStylesForTextPane() {
        //Initialize some styles.
        Style def = StyleContext.getDefaultStyleContext().
                                        getStyle(StyleContext.DEFAULT_STYLE);

        Style regular = textPane.addStyle("regular", def);
        StyleConstants.setFontFamily(def, "SansSerif");

        Style s = textPane.addStyle("italic", regular);
        StyleConstants.setItalic(s, true);

        s = textPane.addStyle("bold", regular);
        StyleConstants.setBold(s, true);

        s = textPane.addStyle("small", regular);
        StyleConstants.setFontSize(s, 10);

        s = textPane.addStyle("large", regular);
        StyleConstants.setFontSize(s, 16);

        s = textPane.addStyle("comment", regular);
        StyleConstants.setForeground(s, Color.GRAY);

        s = textPane.addStyle("question", regular);
        StyleConstants.setForeground(s, Color.GREEN);

        s = textPane.addStyle("rulebase", regular);
        StyleConstants.setForeground(s, Color.RED);
        StyleConstants.setBold(s, true);

        s = textPane.addStyle("keyword", regular);
        StyleConstants.setForeground(s, Color.BLUE);
        StyleConstants.setBold(s, true);
    }


    //initialize
    private void initTextPane() {
        addText("\n This didactic tab imports/exports ontologies from  TaXonomic RuleML");
        addText("\n\n IMPORT OPTION:","bold");
        addText("\n                  Source:           the selected TXRuleML file");
        addText("\n                  Destionation:     the current ontology");
        addText("\n                                  observation:  All the classes will be added to the existing taxonomy.","small");
        addText("\n\n EXPORT OPTION:","bold");
        addText("\n                  Source:           the current ontology");
        addText("\n                  Destionation:     the selected TXRuleML file");
        addText("\n\n\n    TERM PROJECT:","Large");
        addText("\n                    University of New Brunswick");
        addText("\n                    Computer Science department");
        addText("\n                    Semantic Web Techniques  CS6995");
        addText("\n\n                    Authors: (alphabetical order)");
        addText("\n                           Iosif-Viorel Onut   ","bold");addText("ID: 3168236");
        addText("\n                           Sandeep Singh     ","bold");addText("ID: 3161493");
    }

    public void addText(String sText,String sStyle) {

        //System.out.println(sText);
        doc = textPane.getDocument();
        try {
            doc.insertString(doc.getLength(), sText, textPane.getStyle(sStyle));
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    public void addText(String sText) {

        //System.out.println(sText);
        doc = textPane.getDocument();
        try {
            doc.insertString(doc.getLength(), sText, textPane.getStyle("regular"));
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    public void clearText() {
        doc = textPane.getDocument();
        try {
            doc.remove(0,doc.getLength());
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    public void historyAddText(String sText) {
        history.append(sText + "\n");
        history.setCaretPosition(history.getDocument().getLength());
    }

    public void historyClearText() {
        history.removeAll();
    }

//_______________________________________________________________________________________

    // INPORT ACTION
    public void actionImport() {

        myFileFilter txtFilter = new myFileFilter("txt", "TeXT Files");
        myFileFilter bothFilter = new myFileFilter(new String[] {"ruleml", "txt"}, "TaXonomic RuleML and TeXT Files");

        txtFilter.setExtensionListInDescription(true);
        bothFilter.setExtensionListInDescription(true);

        fileChooser.addChoosableFileFilter(txtFilter);
        fileChooser.addChoosableFileFilter(bothFilter);
        fileChooser.setFileFilter(rulemlFilter);

        int returnVal = fileChooser.showOpenDialog(TXRuleMLTab.this);
        fileChooser.removeChoosableFileFilter(txtFilter);
        fileChooser.removeChoosableFileFilter(bothFilter);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            if (file.isFile()==false) {
                historyAddText("  Invalid FILE : " + file.getName() + ".");
            }
            else {
                historyAddText("Opening: " + file.getName() + ".");
                historyAddText("         " + file.getAbsoluteFile() + ".");
                rulemlConnection.setFile(file);
                // print + create taxonomy
                rulemlConnection.processTheFile(true);
            }

        } else {
            historyAddText("Open command cancelled by user.\n");
        }
    }

    // EXPORT ACTION
    public void actionExport() {

        clearText();
        fileChooser.setFileFilter(rulemlFilter);
        int returnVal = fileChooser.showSaveDialog(TXRuleMLTab.this);

        if (returnVal == JFileChooser.APPROVE_OPTION) {

            File file = fileChooser.getSelectedFile();

            String s = file.getName();
            File newFile = null;
            if(s.indexOf(".ruleml")==-1) {
                newFile = new File(file.getAbsolutePath()+".ruleml");
            } else {
                newFile = new File(file.getAbsolutePath());
            }
            file = newFile;
            if (file.isFile()== true) {
                // @todo   The user MUST see a popup dialog with :  Do you want to rewrite the existing file ?   YES/NO
                historyAddText("  FILE : " + file.getName() + " EXISTS, It was rewritten.");
                file.delete();
            }
            historyAddText("Saving: "  + file.getName() + ".");
            historyAddText("         " + file.getAbsoluteFile() + ".");
            rulemlConnection.setFile(file);
            rulemlConnection.createTheFile();
            // print + WITHOUT taxonomy
            rulemlConnection.processTheFile(false);
        } else {
            historyAddText("Save command cancelled by user.");
        }

    }

    public static void main(String[] args) {
        edu.stanford.smi.protege.Application.main(args);
    }
}
