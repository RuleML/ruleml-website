package TXRuleMLTab;

import java.io.BufferedReader;
import java.io.IOException;


class StackOfStrings {            //used by parser

    private class Node {
        // An object of type Node holds one of the
        // items in the linked list that represents the stack.
        String item;
        Node next;
    }

    private Node top;  // Pointer to the Node that is at the top of
    //   of the stack.  If top == null, then the
    //   stack is empty.

    public void push( String s ) {
        // Add N to the top of the stack.
        Node newTop;         // A Node to hold the new item.
        newTop = new Node();
        newTop.item = s;     // Store N in the new Node.
        newTop.next = top;   // The new Node points to the old top.
        top = newTop;        // The new item is now on top.
    }

    public String pop() {
        // Remove the top item from the stack, and return it.
        // Note that this routine will throw a NullPointerException
        // if an attempt is made to pop an item from an empty
        // stack.  (It would be better style to define a new
        // type of Exception to throw in this case.)
        String topItem = top.item;  // The item that is being popped.
        top = top.next;    // The previous second item is now on top.
        return topItem;
    }
    public String peek() {
        String item = pop();
        push(item);
        return item;
    }

    public boolean isEmpty() {
        // Returns true if the stack is empty.  Returns false
        // if there are one or more items on the stack.
        if (top == null)
            return true;
        else
            return false;
    }

} // end class StackOfStrings


class Parser {

    public static boolean ParseFile ( BufferedReader in )
    {
        try
        {
            StackOfStrings stack = new StackOfStrings();


            boolean commentflag = false;
            boolean questionflag = false;
            boolean rulebaseflag = false;
            boolean subflag = false;
            boolean sheadflag = false;
            boolean relflag = false;
            boolean sbodyflag = false;
            boolean sorflag = false;
            boolean sheadoccurenceflag=false;
            boolean sbodyoccurenceflag=false;
            String s = null;
            int smallest = 0;

            String token = null;
            String currentLine = null;
            currentLine = in.readLine();

            while (currentLine!= null){

                do{
                    smallest=-999;
                    token = null;
                    int i1 = currentLine.indexOf("<!--");
                    if (i1 > -1)
                        if ((smallest == -999)  || (i1<=smallest)){smallest = i1;token="<!--";}

                    int i2 = currentLine.indexOf("-->");
                    if (i2 > -1)
                        if((smallest == -999) || (i2<=smallest)) {smallest=i2;token="-->";}

                    if (commentflag == false){ //ignore evertyhing in comments

                    int i3 = currentLine.indexOf("<?");
                    if (i3 > -1)
                        if((smallest == -999) || (i3<=smallest)) {smallest=i3;token="<?";}

                    int i4 = currentLine.indexOf("?>");
                    if (i4 > -1)
                        if((smallest == -999) || (i4<=smallest)) {smallest=i4;token="?>";}

                    int i5 = currentLine.indexOf("<rulebase>");
                    if (i5 > -1)
                        if((smallest == -999) || (i5<=smallest)) {smallest=i5;token="<rulebase>";}

                    int i6 = currentLine.indexOf("</rulebase>");
                    if (i6 > -1)
                        if((smallest == -999) || (i6<=smallest)) {smallest=i6;token="</rulebase>";}

                    int i7 = currentLine.indexOf("<sub>");
                    if (i7 > -1)
                        if((smallest == -999) || (i7<=smallest)) {smallest=i7;token="<sub>";}

                    int i8 = currentLine.indexOf("</sub>");
                    if (i8 > -1)
                        if((smallest == -999) || (i8<=smallest)) {smallest=i8;token="</sub>";}

                    int i9 = currentLine.indexOf("<_shead>");
                    if (i9 > -1)
                        if((smallest == -999) || (i9<=smallest)) {smallest=i9;token="<_shead>";}

                    int i10 = currentLine.indexOf("</_shead>");
                    if (i10 > -1)
                        if((smallest == -999) || (i10<=smallest)) {smallest=i10;token="</_shead>";}

                    int i11 = currentLine.indexOf("<rel>");
                    if (i11 > -1)
                        if((smallest == -999) || (i11<=smallest)) {smallest=i11;token="<rel>";}

                    int i12 = currentLine.indexOf("</rel>");
                    if (i12 > -1)
                        if((smallest == -999) || (i12<=smallest)) {smallest=i12;token="</rel>";}

                    int i13 = currentLine.indexOf("<_sbody>");
                    if (i13 > -1)
                        if((smallest == -999) || (i13<=smallest)) {smallest=i13;token="<_sbody>";}

                    int i14 = currentLine.indexOf("</_sbody>");
                    if (i14 > -1)
                        if((smallest == -999) || (i14<=smallest)) {smallest=i14;token="</_sbody>";}

                    int i15 = currentLine.indexOf("<sor>");
                    if (i15 > -1)
                        if((smallest == -999) || (i15<=smallest)) {smallest=i15;token="<sor>";}

                    int i16 = currentLine.indexOf("</sor>");
                    if (i16 > -1)
                        if((smallest == -999) || (i16<=smallest)) {smallest=i16;token="</sor>";}
                    } //end if :commentflag condition
                    if(token == null && commentflag == false && currentLine.equals("") == false ){
                        return false;
                    }
                    if(token == null){
                        break;
                    }

                    if(token.equals("<!--")==true){
                        stack.push(token);
                        commentflag = true;
                    }
                    if(token.equals("-->")==true){
                        s = stack.pop();
                        if (stack.isEmpty() == true)
                         commentflag = false;
                        if (s.equals("<!--")==false){
                            return false;
                        }
                        if (stack.isEmpty() == false){
                        s = stack.peek();
                        if (s.equals("<!--")==false)
                            commentflag = false;
                        }
                    }
                    if(token.equals("<?")==true){
                        if(rulebaseflag == true){
                            return false;
                        }
                        stack.push(token);
                        questionflag = true;
                    }
                    if(token.equals("?>")==true){
                        s = stack.pop();
                        if (s.equals("<?")==false){
                            return false;
                        }
                        questionflag = false;
                    }
                    if(token.equals("<rulebase>")==true){
                        if(rulebaseflag == true){
                            return false;
                        }else{
                            stack.push("<rulebase>");
                            rulebaseflag = true;
                        }
                    }
                    if(token.equals("</rulebase>")==true){
                        s = stack.pop();
                        rulebaseflag=false;
                        if(s.equals("<rulebase>")==false)
                        {
                            return false;
                        }
                    }
                    if(token.equals("<sub>")==true){
                        if(rulebaseflag == false){
                            return false;
                        }else{
                            stack.push("<sub>");
                            subflag = true;
                        }
                    }
                    if(token.equals("</sub>")==true){
                        s = stack.pop();
                        subflag=false;
                        sheadflag=false;
                        sheadoccurenceflag=false;
                        sbodyoccurenceflag=false;
                        if(s.equals("<sub>")==false)
                        {
                            return false;
                        }
                    }
                    if(token.equals("<_shead>")==true){
                        if(subflag == false){
                            return false;
                        }
                        if(sbodyflag==true){
                            return false;
                        }
                        if(sbodyoccurenceflag==true){
                            return false;
                        }
                        if(sheadoccurenceflag==true){
                            return false;
                        }

                        stack.push("<_shead>");
                        sheadflag = true;
                        sheadoccurenceflag = true;

                    }
                    if(token.equals("</_shead>")==true){
                        s = stack.pop();
                        sheadflag=false;
                        if(s.equals("<_shead>")==false){
                            return false;
                        }
                    }
                    if(token.equals("<rel>")==true){
                        if(subflag == false&&sorflag==false){
                            return false;
                        }
                        stack.push("<rel>");
                        relflag = true;
                    }
                    if(token.equals("</rel>")==true){
                        s = stack.pop();
                        relflag=false;
                        if(s.equals("<rel>")==false)
                        {
                            return false;
                        }
                    }
                    if(token.equals("<_sbody>")==true){
                        if(subflag == false){
                            return false;
                        }
                        if(sheadoccurenceflag == false){
                            return false;
                        }
                        if(sheadflag == true){
                            return false;
                        }
                        if(sbodyflag == true){
                            return false;
                        }
                        stack.push("<_sbody>");
                        sbodyflag = true;
                        sbodyoccurenceflag=true;
                    }
                    if(token.equals("</_sbody>")==true){
                        s = stack.pop();
                        sbodyflag=false;
                        if(s.equals("<_sbody>")==false){

                            return false;
                        }
                    }
                    if(token.equals("<sor>")==true){
                        if(sbodyflag == false){
                            return false;
                        }
                        stack.push("<sor>");
                        sorflag = true;
                    }
                    if(token.equals("</sor>")==true){
                        s = stack.pop();
                        sorflag=false;
                        if(s.equals("<sor>")==false){
                            return false;
                        }
                    }


                    if (smallest + token.length() >= currentLine.length() ){
                        break;
                    }

                    currentLine = currentLine.substring(smallest + token.length());
                    //String token = getNextToken();
                    if(currentLine == null){
                        break;//the line is finished go to the outer loop to get the next line
                    }

                }while(true);
                try {                    //read a new line from the file
                    currentLine = in.readLine();
                } catch (IOException e) {
                    e.printStackTrace();  //To change body of catch statement use Options | File Templates.
                }

            } //end of outer while loop
            if (stack.isEmpty() == true)
            return true;
            else
            return false;

         }//end try
        catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }//end catch
     return false; //by default returns false
    }//end main()
}//end class parser





