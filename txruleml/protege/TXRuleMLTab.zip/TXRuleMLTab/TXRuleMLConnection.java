package TXRuleMLTab;

import java.io.*;

/**
 * User: student
 * Date: Nov 3, 2002
 * Time: 11:24:19 AM
 */

public class TXRuleMLConnection {
    private File file;
    private OntologyConnection ontoConnection;
    private TXRuleMLTab txTab;
    private int Intentation;
    private int isComment;
    private int isQuestion;
    private boolean isShead;
    private boolean isSrel;
    private boolean isSbody;
    // the current SupperCalss
    String currentSuperClass;
    // the current SubClass
    String currentSubClass;

    /**
    * The Constructor
    */
    public TXRuleMLConnection(OntologyConnection ontoConnection,TXRuleMLTab txTab)
    {
        this.ontoConnection = ontoConnection;
        this.txTab=txTab;
        Intentation = 0;
        isComment = 0;
        isQuestion = 0;
        isShead = false;
    }

    public void setFile(File file) {
        this.file=file;
    }

    public void processTheFile(boolean createTaxonomy) {
        txTab.clearText();

        try {
            // open the file
            BufferedReader in = new BufferedReader(new FileReader(file.getAbsoluteFile()));

            // validate the file

            BufferedReader inTest =  new BufferedReader(new FileReader(file.getAbsoluteFile()));
            if (Parser.ParseFile(inTest)==true) {
                // teh file is valid ==>  process it !!!
                String currentLine = in.readLine();
                while(currentLine != null) {
                    processTheLine(currentLine, createTaxonomy);
                    currentLine = in.readLine();
                }
            } else {
                //  the file is invalid  ==> ignore the file !!!
                txTab.historyAddText("ERROR The file : " + file.getName() + " is not well formed !!!\n");
            }
            // close the file
            inTest.close();
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
            txTab.historyAddText("ERROR while processing file: " + file.getName() + " !!!\n");
        }
    }

    private void printBlanks(){
        // prepare to process the current line
        txTab.addText("\n");
        int temp = Intentation;
        while (temp > 0) {
            txTab.addText(" ");
            temp--;
        }
    }

    public void processTheLine(String currentLine, boolean createTaxonomy){
        int intentationAmount =10;
        int closeSymbol = 0;
        int openSymbol = 0;
        String remaining = "";

        // trim the line
        String currentLineTrim = currentLine.trim();

        if (currentLineTrim.equals("")) {
            txTab.addText("\n");
            return;
        }


        if ((isShead)&&(isSrel)&&(isComment == 0)) {
            // the name of the suppercalss
            // find the first occurance of </rel>   or <!--
            printBlanks();
            int endName = currentLineTrim.toLowerCase().indexOf("<");
            if (endName == -1) {
                // the whole line is the name
                currentSuperClass = currentLineTrim;
                txTab.addText(currentSuperClass,"bold");
                if (createTaxonomy) ontoConnection.GetCreateClass(currentSuperClass);
                return;
            } else {
                currentSuperClass = currentLineTrim.substring(0,endName);
                txTab.addText(currentSuperClass,"bold");
                if (createTaxonomy) ontoConnection.GetCreateClass(currentSuperClass);
                currentLine = currentLineTrim.substring(endName);
                currentLineTrim = currentLine;
            }
        }

        if ((isSbody)&&(isSrel)&&(isComment == 0)) {
            // the name of the subclass
            // find the first occurance of </rel>   or <!--
            printBlanks();
            int endName = currentLineTrim.toLowerCase().indexOf("<");
            if (endName == -1) {
                // the whole line is the name
                currentSubClass = currentLineTrim;
                txTab.addText(currentSubClass,"bold");
                if (createTaxonomy) ontoConnection.GetCreateClass(currentSubClass,ontoConnection.GetCreateClass(currentSuperClass));
                return;
            } else {
                currentSubClass = currentLineTrim.substring(0,endName);
                txTab.addText(currentSubClass,"bold");
                if (createTaxonomy) ontoConnection.GetCreateClass(currentSubClass,ontoConnection.GetCreateClass(currentSuperClass));
                currentLine= currentLineTrim.substring(endName);
                currentLineTrim = currentLine;
            }
        }


        //    PRIORITY   1    =>    COMMENTS
        // check if is a comment
        if (currentLineTrim.startsWith("<!--")) {
            // this is a comment ...
            isComment +=1;
            txTab.addText("\n<!--","bold");
            remaining = currentLineTrim.substring(4);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is IN A comment
        if (isComment != 0) {
            // SEARCH IF THERE ARE IMBRICATED COMMENTS
            openSymbol = currentLine.indexOf("<!--");
            if (openSymbol != -1) {
                txTab.addText(currentLine.substring(0,openSymbol),"comment");
                processTheLine(currentLine.substring(openSymbol), createTaxonomy);
                return;
            }

            // search for end comment ...
            closeSymbol = currentLine.indexOf("-->");
            if (closeSymbol == -1) {
                // the entire line is a comment    -->   PRINT THE LINE as a comment
                txTab.addText(currentLine+"\n","comment");
                return;
            } else {
                // only a fragment of the line is a comment  -->  PRINT THE FRAGMENT as a comment
                txTab.addText(currentLine.substring(0,closeSymbol),"comment");
                txTab.addText("-->\n","bold");
                isComment-=1;
                //                                           -->  PROCESS the remaining fragment
                remaining = currentLine.substring(closeSymbol+3);
                if (!remaining.trim().equals(""))
                    processTheLine(remaining, createTaxonomy);
                return;
            }
        }


        //    PRIORITY   2    =>    QUESTIONS
        // check if is a question
        if (currentLineTrim.startsWith("<?")) {
            // this is a comment ...
            isQuestion +=1;
            txTab.addText("\n<?","bold");
            remaining = currentLineTrim.substring(2);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is IN A question
        if (isQuestion != 0) {

            // SEARCH IF THERE ARE IMBRICATED COMMENTS
            int openSymbolComment = currentLine.indexOf("<!--");
            // SEARCH IF THERE ARE imbricated Questions
            int openSymbolQuestion = currentLine.indexOf("<?");

            // who is first ?
            if ((openSymbolComment != -1) && (openSymbolQuestion != -1)) {
                if (openSymbolComment < openSymbolQuestion) {
                    openSymbol = openSymbolComment;
                }  else {
                    openSymbol = openSymbolQuestion;
                }
            } else {
                if (openSymbolComment != -1) {
                    openSymbol = openSymbolComment;
                }  else {
                    openSymbol = openSymbolQuestion;
                }
            }


            // search for end question
            closeSymbol = currentLine.indexOf("?>");

            if ((closeSymbol != -1) && (closeSymbol > openSymbol) && (openSymbol != -1)||
                (closeSymbol == -1) && (openSymbol != -1)) {
                txTab.addText(currentLine.substring(0,openSymbol),"question");
                processTheLine(currentLine.substring(openSymbol), createTaxonomy);
                return;
            }

            if (closeSymbol == -1) {
                // the entire line is a question    -->   PRINT THE LINE as a question
                txTab.addText(currentLine+"\n","question");
                return;
            } else {
                // only a fragment of the line is a question  -->  PRINT THE FRAGMENT as a question
                txTab.addText(currentLine.substring(0,closeSymbol),"question");
                txTab.addText("?>\n","bold");
                isQuestion-=1;
                //                                           -->  PROCESS the remaining fragment
                remaining = currentLine.substring(closeSymbol+2);
                if (!remaining.trim().equals(""))
                    processTheLine(remaining, createTaxonomy);
                return;
            }
        }

        // current line IS NOT in a comment or a question

        //    PRIORITY   3    =>    RULEBASE
        // check if is a RULEBASE
        if (currentLineTrim.toLowerCase().startsWith("<rulebase>")) {
            // this is a rulebase ...
            txTab.addText("<rulebase>","rulebase");
            remaining = currentLineTrim.substring(10);
            this.Intentation+=intentationAmount;
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is a ENDRULEBASE
        if (currentLineTrim.toLowerCase().startsWith("</rulebase>")) {
            // this is the end rulebase ...
            this.Intentation-=intentationAmount;
            txTab.addText("\n</rulebase>","rulebase");
            remaining = currentLineTrim.substring(11);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        //    PRIORITY   4    =>    SUB
        // check if is a SUB
        if (currentLineTrim.toLowerCase().startsWith("<sub>")) {
            printBlanks();
            txTab.addText("<sub>","keyword");
            remaining = currentLineTrim.substring(5);
            this.Intentation+=intentationAmount;
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }
        // check if is a ENDsub
        if (currentLineTrim.toLowerCase().startsWith("</sub>")) {
            this.Intentation-=intentationAmount;
            printBlanks();
            txTab.addText("</sub>","keyword");
            remaining = currentLineTrim.substring(6);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is a <_shead>
        if (currentLineTrim.toLowerCase().startsWith("<_shead>")) {
            isShead = true;
            printBlanks();
            txTab.addText("<_shead>","keyword");
            remaining = currentLineTrim.substring(8);
            this.Intentation+=intentationAmount;
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }
        // check if is a <_shead>
        if (currentLineTrim.toLowerCase().startsWith("</_shead>")) {
            isShead = false;
            this.Intentation-=intentationAmount;
            printBlanks();
            txTab.addText("</_shead>","keyword");
            remaining = currentLineTrim.substring(9);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is a <rel>
        if (currentLineTrim.toLowerCase().startsWith("<rel>")) {
            isSrel = true;
            printBlanks();
            txTab.addText("<rel>","keyword");
            remaining = currentLineTrim.substring(5);
            this.Intentation+=intentationAmount;
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }
        // check if is a <_rel>
        if (currentLineTrim.toLowerCase().startsWith("</rel>")) {
            isSrel = false;
            this.Intentation-=intentationAmount;
            printBlanks();
            txTab.addText("</rel>","keyword");
            remaining = currentLineTrim.substring(6);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is a <_sbody>
        if (currentLineTrim.toLowerCase().startsWith("<_sbody>")) {
            isSbody = true;
            printBlanks();
            txTab.addText("<_sbody>","keyword");
            remaining = currentLineTrim.substring(8);
            this.Intentation+=intentationAmount;
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }
        // check if is a </_sbody>
        if (currentLineTrim.toLowerCase().startsWith("</_sbody>")) {
            isSbody = false;
            this.Intentation-=intentationAmount;
            printBlanks();
            txTab.addText("</_sbody>","keyword");
            remaining = currentLineTrim.substring(9);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }

        // check if is a <sor>
        if (currentLineTrim.toLowerCase().startsWith("<sor>")) {
            printBlanks();
            txTab.addText("<sor>","keyword");
            remaining = currentLineTrim.substring(5);
            this.Intentation+=intentationAmount;
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }
        // check if is a </sor>
        if (currentLineTrim.toLowerCase().startsWith("</sor>")) {
            this.Intentation-=intentationAmount;
            printBlanks();
            txTab.addText("</sor>","keyword");
            remaining = currentLineTrim.substring(6);
            if (!remaining.trim().equals(""))
                processTheLine(remaining, createTaxonomy);
            return;
        }
    }


    public void createTheFile() {
        try {
            file.createNewFile();
            BufferedWriter out = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));

            // write the head comments ...

            out.write("<!-- THIS FILE WAS AUTOMATICALLY GENERATED -->"); out.newLine();
            out.write("<!--"); out.newLine();
            out.write("            The taxonomy was initially stored in Protege-2000"); out.newLine();out.newLine();
            out.write("    TERM PROJECT:");out.newLine();
            out.write("                    University of New Brunswick");out.newLine();
            out.write("                    Computer Science department");out.newLine();
            out.write("                    Semantic Web Techniques  CS6995");out.newLine();out.newLine();
            out.write("                    Authors: (alphabetical order)");out.newLine();
            out.write("                           Iosif-Viorel Onut   ID: 3168236");out.newLine();
            out.write("                           Sandeep Singh       ID: 3161493");out.newLine();
            out.write("-->"); out.newLine();

            // write <rulebase>
            out.newLine();
            out.write("<rulebase>");

            ontoConnection.populateTheTXRuleMLFile(out);

            // write </rulebase>
            out.newLine();
            out.newLine();
            out.write("</rulebase>");
            out.close();
        } catch (IOException e) {
            txTab.historyAddText("ERROR while saving file: " + file.getName() + " !!!\n");
            e.printStackTrace();
        }

    }
}
