package TXRuleMLTab;

import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Cls;

import java.util.Collections;
import java.util.Iterator;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 * User: student
 * Date: Nov 3, 2002
 * Time: 11:23:50 AM
*/

/**
 * This class implements the connection to ontology
 */
public class OntologyConnection
{
    private KnowledgeBase kb = null;
    private Cls clsNew = null;
    private BufferedWriter out;

     /**
     * The Constructor
     */
    public OntologyConnection(KnowledgeBase NewKB)  {
         this.kb = NewKB;
    }

     public Cls GetCreateClass(String name,Cls clsSuper) {
        clsNew=kb.getCls(name.trim());
        if (clsNew == null) {
            // create class
            clsNew = kb.createCls(name.trim(), Collections.singleton(clsSuper));
            clsNew.setAbstract(false);
        } else {
            clsNew.addDirectSuperclass(clsSuper);
            // delete the :THING superclass
            clsNew.removeDirectSuperclass(kb.getCls(":THING"));
        }
        return clsNew;
    }

    public Cls GetCreateClass(String name) {
        clsNew=kb.getCls(name.trim());
        if (clsNew == null) {
            // create class
            clsNew = kb.createCls(name.trim(), kb.getRootClses());
            clsNew.setAbstract(false);
        }
        return clsNew;
    }


    private String createBlanks(int no){
        String ss="";
        int temp = no;
        while (temp > 0) {
            ss = ss +" ";
            temp--;
        }
        return ss;
    }


    private void printTheSUB(Cls currentCls) {
        int intent =5;
        try {
            out.newLine();
            out.newLine(); out.write(createBlanks(intent)+"<sub>");
            out.newLine(); out.write(createBlanks(intent*2)+"<_shead>");
            out.write("<rel>");
            out.write(currentCls.getName());
            out.write("</rel>");
            out.write("</_shead>");
            out.newLine(); out.write(createBlanks(intent*2)+"<_sbody>");
            out.newLine(); out.write(createBlanks(intent*3)+"<sor>");

            Iterator i = currentCls.getDirectSubclasses().iterator();
            while (i.hasNext()) {
                out.newLine(); out.write(createBlanks(intent*4)+"<rel>");
                out.write(((Cls) i.next()).getName());
                out.write("</rel>");
            }

            out.newLine(); out.write(createBlanks(intent*3)+"</sor>");
            out.newLine(); out.write(createBlanks(intent*2)+"</_sbody>");
            out.newLine(); out.write(createBlanks(intent)+"</sub>");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void resolve(Cls currentCls) {
        Iterator i = currentCls.getDirectSubclasses().iterator();
        boolean noChildrens = true;
        while (i.hasNext()) {
            noChildrens = false;
            resolve((Cls) i.next());
        }
        // if the class does not have any subClasses than do nothing !
        if (noChildrens) {
            return;
        } else {
            // we can now print the current class because all it's subclasses has been considerated already
            printTheSUB(currentCls);
        }
    }


    public void populateTheTXRuleMLFile(BufferedWriter out) {
        this.out=out;
        Cls root;
        root = kb.getCls(":THING");

        // search for all direct subclasses of the :THING class
        Iterator i = root.getDirectSubclasses().iterator();
        while (i.hasNext()) {
            Cls cls = (Cls) i.next();
            if (!(cls.getName().equals(":SYSTEM-CLASS")))
                resolve(cls);
        }
    }
}
