
    /**
     * RuleMLValidationServiceCallbackHandler.java
     *
     * This file was auto-generated from WSDL
     * by the Apache Axis2 version: 1.1 Nov 13, 2006 (07:31:44 LKT)
     */
    package src.org.apache.ws.axis2;

    /**
     *  RuleMLValidationServiceCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class RuleMLValidationServiceCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public RuleMLValidationServiceCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public RuleMLValidationServiceCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
           /**
            * auto generated Axis2 call back method for TranslateRuleMLURI method
            *
            */
           public void receiveResultTranslateRuleMLURI(
        		   src.org.apache.ws.axis2.RuleMLValidationServiceStub.TranslateRuleMLURIResponse param1) {
           }

          /**
           * auto generated Axis2 Error handler
           *
           */
            public void receiveErrorTranslateRuleMLURI(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for validURI method
            *
            */
           public void receiveResultvalidURI(
        		   src.org.apache.ws.axis2.RuleMLValidationServiceStub.ValidURIResponse param3) {
           }

          /**
           * auto generated Axis2 Error handler
           *
           */
            public void receiveErrorvalidURI(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for validationW3C method
            *
            */
           public void receiveResultvalidationW3C(
        		   src.org.apache.ws.axis2.RuleMLValidationServiceStub.ValidationW3CResponse param5) {
           }

          /**
           * auto generated Axis2 Error handler
           *
           */
            public void receiveErrorvalidationW3C(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for TranslateRuleMLFile method
            *
            */
           public void receiveResultTranslateRuleMLFile(
        		   src.org.apache.ws.axis2.RuleMLValidationServiceStub.TranslateRuleMLFileResponse param7) {
           }

          /**
           * auto generated Axis2 Error handler
           *
           */
            public void receiveErrorTranslateRuleMLFile(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for validFile method
            *
            */
           public void receiveResultvalidFile(
        		   src.org.apache.ws.axis2.RuleMLValidationServiceStub.ValidFileResponse param9) {
           }

          /**
           * auto generated Axis2 Error handler
           *
           */
            public void receiveErrorvalidFile(java.lang.Exception e) {
            }
                


    }
    