import src.org.apache.ws.axis2.RuleMLValidationServiceStub.*;
import src.org.apache.ws.axis2.RuleMLValidationServiceStub;


public class RuleMLClient {
	
	 public static void main(String[] args) throws Exception {
		 
		 if (args.length < 2 || args.length > 3) {
				programUsage();
				System.out.println("Please give a valid number of arguments!");
			} else {
				if(args[0].equals("validationW3C")){
					validationW3CClient(args[1]);
					
				}
				else if(args[0].equals("validURI")){
					validURIClient(args[1]);
					
				}
				else if(args[0].equals("validFile")){
					validFileClient(args[1]);
					
				}
				else if(args[0].equals("TranslateRuleMLURI")){
					TranslateRBSLAURIClient(args[1],args[2]);
					
				}
				else if(args[0].equals("TranslateRuleMLFile")){
					TranslateRBSLAFileClient(args[1],args[2]);
					
				}
				else{
					programUsage();
					System.out.println(args[0] + " is not a valid function.");
					System.out.println("Please give a valid function!");
				}

			}
		  }
	
		/**
		 *  Prints usage instruction out
		 */
		public static void programUsage(){
			System.out.println(" ");
			System.out.println("-----------------------------------------------------------------");
			System.out.println("Usage: RuleMLValidationClient function parameter1 [parameter2]");
			System.out.println("-----------------------------------------------------------------");
			System.out.println("Functions : ");
			System.out.println("validationW3C - call to the W3C schema validator.");
			System.out.println("validFile - check a local file for @kind attribute validity.");
			System.out.println("validURI - check an online document  for @kind attribute validity.");
			System.out.println("TranslateRBSLAFile - translate a local file to Prova.");
			System.out.println("TranslateRBSLAURI - translate an online document to Prova.");
			System.out.println("-----------------------------------------------------------------");
			System.out.println("Use one parameter for validationW3C, validFile, validURI");
			System.out.println("and two for TranslateRBSLAFile and TranslateRBSLAURI.");
			System.out.println("-----------------------------------------------------------------");
			System.out.println("Examples : ");
			System.out.println("java RuleMLClient validationW3C http://ibis.in.tum.de/research/ReactionRuleML/0.1/examples/reaction_testcase.rrml");
			System.out.println("java RuleMLClient validFile http://ibis.in.tum.de/research/ReactionRuleML/0.1/examples/reaction_testcase.rrml");
			System.out.println("java RuleMLClient validURI http://ibis.in.tum.de/research/ReactionRuleML/0.1/examples/reaction_testcase.rrml");
			System.out.println("java RuleMLClient TranslateRuleMLFile http://ibis.in.tum.de/research/ReactionRuleML/0.1/examples/reaction_testcase.rrml http://srvbichler6.informatik.tu-muenchen.de:9090/rbsla/ruleml2prova.xsl");
			System.out.println("java RuleMLClient TranslateRuleMLURI myFile.rrml http://srvbichler6.informatik.tu-muenchen.de:9090/rbsla/ruleml2prova.xsl");
			System.out.println("-----------------------------------------------------------------");
			System.out.println(" ");
		}
		
		/**
		 *  calls the validationW3C method from the service RBSLAValidationService
		 *  @param String url - the url of the document to validate 
		 */
		public static void validationW3CClient(String url){
			try {
				RuleMLValidationServiceStub stub = new RuleMLValidationServiceStub();				 
				 //Create the request
				RuleMLValidationServiceStub.ValidationW3C request  = new RuleMLValidationServiceStub.ValidationW3C();
				 //Set the request params
				 request.setUrl("url");
				 //Invoke the service
				 ValidationW3CResponse response = stub.validationW3C(request);
				//Print the result out
				 System.out.println(response.get_return());
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		/**
		 *  calls the validFile method from the service RuleMLValidationService
		 *  @param Call rpc - the rpc call to the service 
		 *  @param String fileName - the name of the local file to validate
		 */
		public static void validFileClient(String fileName){
			try {
				 RuleMLValidationServiceStub stub = new RuleMLValidationServiceStub();				 
				 //Create the request
				 RuleMLValidationServiceStub.ValidFile request  = new RuleMLValidationServiceStub.ValidFile();
				 //Set the request params
				 request.setFileName(fileName);
				 //Invoke the service
				 ValidFileResponse response = stub.validFile(request);
				//Print the result out
				 System.out.println(response.get_return());
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		/**
		 *  calls the validURI method from the service RuleMLValidationService
		 *  @param Call rpc - the rpc call to the service 
		 *  @param String url - the url of the document to validate
		 */
		public static void validURIClient(String url){
			try {
				 RuleMLValidationServiceStub stub = new RuleMLValidationServiceStub();				 
				 //Create the request
				 RuleMLValidationServiceStub.ValidURI request  = new RuleMLValidationServiceStub.ValidURI();
				 //Set the request params
				 request.setUrl(url);
				 //Invoke the service
				 ValidURIResponse response = stub.validURI(request);
				//Print the result out
				 System.out.println(response.get_return());
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		/**
		 *  calls the TranslateRuleMLFile method from the service RuleMLValidationService
		 *  @param String url - the url of the document to traslate to Prova
		 *  @param String xsl - the stylesheet to use
		 */
		public static void TranslateRBSLAFileClient(String fileName, String xsl){
			try {
				RuleMLValidationServiceStub stub = new RuleMLValidationServiceStub();				 
				 //Create the request
				RuleMLValidationServiceStub.TranslateRuleMLFile request  = new RuleMLValidationServiceStub.TranslateRuleMLFile();
				 //Set the request params
				 request.setFileName(fileName);
				 request.setXsl(xsl);
				 //Invoke the service
				 TranslateRuleMLFileResponse response = stub.TranslateRuleMLFile(request);
				 //Print the result out
			     System.out.println(response.get_return());
				
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		/**
		 *  calls the TranslateRuleMLURI method from the service RuleMLValidationService
		 *  @param String fileName - the name of the local file to traslate to Prova
		 *  @param String xsl - the stylesheet to use
		 */
		public static void TranslateRBSLAURIClient(String url, String xsl){
			try {
				 RuleMLValidationServiceStub stub = new RuleMLValidationServiceStub();				 
				 //Create the request
				 RuleMLValidationServiceStub.TranslateRuleMLURI request  = new RuleMLValidationServiceStub.TranslateRuleMLURI();
				 //Set the rewuest params
				 request.setUrl(url);
				 request.setXsl(xsl);
				 //Invoke the service
				 TranslateRuleMLURIResponse response = stub.TranslateRuleMLURI(request);
				 //Print the result out
			     System.out.println(response.get_return());
				} catch (Exception e) {
					e.printStackTrace();
				}
		}

}
