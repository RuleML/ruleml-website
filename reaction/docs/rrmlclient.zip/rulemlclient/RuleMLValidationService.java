import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.oreilly.servlet.HttpMessage;

public class RuleMLValidationService {
	
	/**
	 * 
	 * Send a Get Request to the W3C validator server 
	 * 
	 * @param url - the URL of the document to validate
	 * @return the W3C validation xml response
	 */
	
	public static String validationW3C(String url){
	    String s="";
		try{
			HttpMessage msg = new HttpMessage(new URL("http://www.w3.org/2001/03/webdata/xsv"));
			// Setting request parameters for W3C
		    Properties props = new Properties();
	        props.put("docAddrs", url);
	        props.put("style", "xsl");
		    props.put("warnings", "on");
		    props.put("keepGoing", "on");
		    // GET request to W3C
		    InputStream in = msg.sendGetMessage(props);
	     	 for(int i=0;(i=in.read())!=-1;){
	     		 s=s.concat(String.valueOf((char) i));  
	     		 System.out.print((char) i);
				  }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return s;

	}
	
	  /**
	   * Returns true if a Reaction RuleML file is valid
	   * otherwise false
	   *     
	   * @param String fileName - the name of the file to be checked for kind-attribute validity
	   * @return boolean
	   * 
	  **/
	
	  public boolean validFile(String fileName){
		  boolean valid=true;
		  try{
			  FileInputStream fis = new FileInputStream(fileName);	
			  NodeList nl = getAttrKindNodes(fis);
			  if(isValid(nl)){
				  valid=true;				  
			  }
			  else{
				  valid=false;				  
			  }
		  }
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  return valid;
	  }
	  
	  /**
	   * Returns true if a Reaction RuleML document is valid
	   * otherwise false
	   *     
	   * @param String url - a file to be checked for kind-attribute validity
	   * @return boolean
	   * 
	  **/
	  public boolean validURI(String url){
		  boolean valid=true;
		  try{
			  URL theUrl = new URL(url);
			  InputStream is = theUrl.openStream();
			  NodeList nl = getAttrKindNodes(is);
			  if(isValid(nl)){
				  valid=true;				  
			  }
			  else{
				  valid=false;				  
			  }
		  }
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  return valid;
	  }
	
	/**
	 * Translate an RuleML file to Prova
	 * @param String fileName - the name of the file to translate
	 * @param String xsl - the stylesheet to use
	 * @return a String representation of the prova translation
	 */
	public String TranslateRuleMLFile(String fileName, String xsl){
		String result="";
		try{
			 TransformerFactory tFactory = TransformerFactory.newInstance();
			 FileInputStream is = new FileInputStream(fileName);
		   	 Source xmlSource = new StreamSource(is);
			 Source xslSource = new StreamSource(xsl);
			 Transformer transformer = tFactory.newTransformer(xslSource);
			 ByteArrayOutputStream bos =  new ByteArrayOutputStream();
			 StreamResult sr = new StreamResult(bos);
	         // Perform the transformation.			
	         transformer.transform(xmlSource, sr);
	         result = bos.toString();
		}
		catch(Exception e){
			e.printStackTrace();
		}	
		return result;
	}	
	
	/**
	 * Translate an RuleML file to Prova
	 * @param String url - the uri of the RuleML document to translate
	 * @param String xsl - the stylesheet to use
	 * @return a String representation of the prova translation
	 */
	public String TranslateRuleMLURI(String url, String xsl){
		String result="";
		try{
			 URL theUrl = new URL(url);
			 TransformerFactory tFactory = TransformerFactory.newInstance();
			 InputStream is = theUrl.openStream();
		   	 Source xmlSource = new StreamSource(is);
			 Source xslSource = new StreamSource(xsl);
			 Transformer transformer = tFactory.newTransformer(xslSource);
			 ByteArrayOutputStream bos =  new ByteArrayOutputStream();
			 StreamResult sr = new StreamResult(bos);
	         // Perform the transformation.			
	         transformer.transform(xmlSource, sr);
	         result = bos.toString();
	         
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}	
	
	  /**
	   * Returns the first element child of a XMLNode
	   *     
	   * @param Node n
	   * @return Node
	   * 
	  **/
	  private Node firstElementChild(Node n){
		Node resultChild=null;
		while(n!=null)
	   {	    	   	
	   	if(n.getNodeType() == Node.ELEMENT_NODE)
	   	{      	   	
	   	resultChild=n;
	   	break;
	   	} 	   	
        //nextes Element
	   	n = n.getNextSibling();
	   }
		return resultChild;
	}
	  /**
	   * Returns an atribute node with name "kind"
	   *     
	   * @param Node n
	   * @return Node
	   * 
	  **/
	  private Node getKindAttr(Node n){
		Node attrNode = null;
		for(int i=0;i<n.getAttributes().getLength();i++){
			if(n.getAttributes().item(i).getNodeName()=="kind")
			attrNode = n.getAttributes().item(i);
	   }
		return attrNode;
	  }
	  
	  /**
	   * Returns the value of an atribute node with name "kind"
	   *     
	   * @param Node n
	   * @return String
	   * 
	  **/
	  private String getKindValue(Node n){
		return getKindAttr(n).getNodeValue();
	  }
	
	  /**
	   * Returns an ArrayList white 1 char long Strings from a String 
	   *     
	   * @param String s
	   * @return ArrayList
	   * 
	  **/
	  private ArrayList getKindsList(String s){
	  ArrayList al = new ArrayList();
	  for(int i=0;i<s.length();i++){
		   int j = i+1;
		   String nextKind = s.substring(i,j);
		   al.add(nextKind);
	   }
	  return al;
	 }
	
	  /**
	   * Returns the count of element children of a XMLNode
	   *     
	   * @param Node node
	   * @return int
	   * 
	  **/
	  private int getElementChildNumber(Node node){
		int count=0;
		Node n=node.getFirstChild();
		while(n!=null)
	   {	    	   	
	   	if(n.getNodeType() == Node.ELEMENT_NODE)
	   	{      	   	
	   		count++;
	   	}
        //next Element
	   	n = n.getNextSibling();
	   }
		return count;
	}		 
	
	  /**
	   * Returns InputStream from a XML File in the net
	   *     
	   * @param String xmlFile - the name of the file
	   * @return InputStream
	   * 
	  **/
	  private InputStream getStreamFromURI(String xmlFile){
		InputStream is  = null;
		try{
			is = new URL(xmlFile).openStream();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return is;
	}
	
	  
	  /**
	   * Returns InputStream from a String
	   *     
	   * @param String xmlText
	   * @return InputStream
	   * 
	  **/
	  private InputStream getStreamFromText(String xmlText){
		ByteArrayInputStream textStream  = null;
		try{
			textStream = new ByteArrayInputStream(xmlText.getBytes());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return textStream;
	}
	
	  /**
	   * Returns all the Nodes in an XML document with a "kind" attribute
	   *     
	   * @param InputStream is
	   * @return NodeList
	   * 
	  **/
	  private NodeList getAttrKindNodes(InputStream is){

      NodeList nodelist  = null;
		String xpath = "//*[@kind]";
  	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
  	   try {

          DocumentBuilder builder = factory.newDocumentBuilder();
          Document document = builder.parse(is);
          
       
          try {
              // Get the matching elements
          	nodelist = org.apache.xpath.XPathAPI.selectNodeList(document, xpath);
          	}
          	catch (javax.xml.transform.TransformerException e) {
          		e.printStackTrace();
          	}                              
             } catch (SAXException sxe) {
             // Error generated during parsing
            	 sxe.printStackTrace();
             } catch (ParserConfigurationException pce) {
              // Parser with specified options can't be built
            	 pce.printStackTrace();
             }
  	   catch (IOException ioe) {
             // I/O error
             ioe.printStackTrace();
             ioe.printStackTrace();
             }
             return nodelist;
	}
	  
	  /**
	   * Returns true if a Reaction RuleML file is valid
	   * otherwise false
	   *     
	   * @param NodeList nodeList - a list of nodes to be checked for kind-attribute validity
	   * @return boolean
	   * 
	  **/
	  private boolean isValid(NodeList nodeList){
		boolean valid = true;
		Node kindV;
		String kindA;
		ArrayList kinds = new ArrayList();
		int kindCount;
		int childrenCount;
		
		if(nodeList == null){
			valid = true;
		}
		else{
			for (int i=0; i<nodeList.getLength(); i++)
			{
				kindV = nodeList.item(i);
				kindA = getKindValue(kindV);
				kinds = getKindsList(kindA);
				kindCount = kinds.size();
				childrenCount = getElementChildNumber(kindV);
				if(kindCount != childrenCount){					
					valid = false;					
					}
				}
			}
		return valid;
		}
	  

	  
	  
	  
}
