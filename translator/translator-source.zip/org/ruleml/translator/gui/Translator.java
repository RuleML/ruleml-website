package org.ruleml.translator.gui;

import org.ruleml.translator.parser.*;
import nu.xom.*;
import com.centerkey.utils.*;

import java.net.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * TRANSLATOR: TRANSlator from LAnguage TO Rules<br>
 * Translates natural language (Attempto Controlled English) into formal rules<br>
 * (Rule Markup Language), taking advantage of the Attempto Parsing Engine webservice<br>
 * Latest Version: <a href="http://www.ruleml.org/translator">http://www.ruleml.org/translator</a><br>
 * Author: David Hirtle<br>
 * @version 1.4, April 28, 2006
 */
public class Translator
{
	private JFrame translatorFrame;
	private JPanel mainPanel, inputPanel, outputPanel, topPanel, radioPanel;
	private JPanel blPanel, brPanel, bottomPanel;
	private JTextArea inputTextArea, outputTextArea;
	private JLabel enterLabel;
	private JButton translateButton, helpButton, saveButton;
	private JScrollPane aceScrollPane, rulemlScrollPane;
	private JCheckBox textButton, paraphraseButton, drsButton, folButton;
	private JFileChooser fc;

	private DRSParser parser;
	private String aceText;
	private String results = null;

	private String rulemlString = null;
	private String drspp, fol, paraphrase, text;
	private String apeMessages = null;
	
	private final static String QUERYBASE= "http://www.ifi.unizh.ch/cgi-bin/kalju/ape/apews.cgi?";
	private final static String PARAMS =
		"cdrs=on&cinput=on&cparaphrase=on&cdrspp=on&cfol=on&text=";
	public final static String RULEML_NAMESPACE = "http://www.ruleml.org/0.9/xsd";
	public final static String RULEML_XSD = "http://www.ruleml.org/0.9/xsd/folog.xsd";
	public final static String SCHEMA_INSTANCE = "http://www.w3.org/2001/XMLSchema-instance";
	public final static String HELP_URL = "http://www.ruleml.org/translator/index.html#Help";
	
	public static void main(String[] args)
	{
		javax.swing.SwingUtilities.invokeLater(new Runnable()
		{
			public void run() { new Translator(); }
		});
	}

	/**
	 * Create and show the translator's GUI.
   */
	public Translator()
	{
		createWidgets();
		createPanels();
		createFrame();
		translatorFrame.setVisible(true);
	}

  /**
	 * Create the widgets for the GUI.
   */
	private void createWidgets()
	{
		inputTextArea = new JTextArea(3,80);
		inputTextArea.setFont( new Font("monospaced", Font.PLAIN, 12) );
		inputTextArea.setLineWrap(true);
		inputTextArea.setWrapStyleWord(true);
		aceScrollPane = new JScrollPane(inputTextArea);

		enterLabel = new JLabel("Enter Attempto Controlled English text:", SwingConstants.LEFT);
		enterLabel.setLabelFor(inputTextArea);
	
		// Get current classloader
		ClassLoader cl = this.getClass().getClassLoader();
		
		// image courtesy of JLFGR: http://java.sun.com/developer/techDocs/hi/repository
		translateButton = new JButton("Translate", new ImageIcon(cl.getResource("images/Down16.gif")));
		translateButton.setMnemonic(KeyEvent.VK_T);
		translateButton.setAlignmentX(Component.CENTER_ALIGNMENT);

    textButton = new JCheckBox("Text");
		textButton.setToolTipText("Include the input (ACE) text in the output.");
    textButton.setMnemonic(KeyEvent.VK_X);
		textButton.setSelected(true);
		
    paraphraseButton = new JCheckBox("Paraphrase");
		paraphraseButton.setToolTipText("Include a paraphrase of the input text in the output.");
    paraphraseButton.setMnemonic(KeyEvent.VK_P);
		paraphraseButton.setSelected(true);
		
		drsButton = new JCheckBox("DRS");
		drsButton.setToolTipText("Include the Discourse Representation Structure in the output.");
		drsButton.setMnemonic(KeyEvent.VK_D);
		drsButton.setSelected(true);

    folButton = new JCheckBox("FOL");
		folButton.setToolTipText("Include the standard First-Order Logic representation in the output.");
    folButton.setMnemonic(KeyEvent.VK_F);
		folButton.setSelected(true);

		outputTextArea = new JTextArea(20,80);
		outputTextArea.setEditable(false);
		outputTextArea.setFont( new Font("monospaced", Font.PLAIN, 12) );
		outputTextArea.setLineWrap(true);
		outputTextArea.setWrapStyleWord(true);
		rulemlScrollPane = new JScrollPane(outputTextArea);

		// image courtesy of JLFGR: http://java.sun.com/developer/techDocs/hi/repository
		helpButton = new JButton("Help", new ImageIcon(cl.getResource("images/Help16.gif")));
		helpButton.setMnemonic(KeyEvent.VK_H);
		
		// image courtesy of JLFGR: http://java.sun.com/developer/techDocs/hi/repository
		saveButton = new JButton("Save", new ImageIcon(cl.getResource("images/Save16.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setEnabled(false);

		fc = new JFileChooser();
		fc.addChoosableFileFilter(new javax.swing.filechooser.FileFilter()
		{
			// accept all directories and all xml or ruleml files
			public boolean accept(File f)
			{
				if (f.isDirectory()) return true;
				String extension = null;
				String s = f.getName();
				int i = s.lastIndexOf('.');
				if (i > 0 &&  i < s.length() - 1) extension = s.substring(i+1).toLowerCase();
				if (extension != null)
				{
					if ((extension.equals("xml")) || (extension.equals("ruleml"))) return true;
					else return false;
				}
				return false;
			}
			
			public String getDescription() { return "XML or RuleML"; }
		});

		// event listeners
    ButtonListener buttonListener = new ButtonListener();
    translateButton.addActionListener(buttonListener);
		helpButton.addActionListener(buttonListener);
		saveButton.addActionListener(buttonListener);
		
		CheckListener checkListener = new CheckListener();
		textButton.addActionListener(checkListener);
		paraphraseButton.addActionListener(checkListener);
		drsButton.addActionListener(checkListener);
		folButton.addActionListener(checkListener);
	}

  /**
	 * Create the JPanels for the GUI.
   */
	private void createPanels()
	{
		topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		topPanel.add(enterLabel);

		inputPanel = new JPanel();
		inputPanel.setBorder(BorderFactory.createCompoundBorder(
                      BorderFactory.createTitledBorder("Input"),
                      BorderFactory.createEmptyBorder(15,15,15,15)));
		inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.PAGE_AXIS));
		inputPanel.add(topPanel);
		inputPanel.add(aceScrollPane);
		inputPanel.add(Box.createRigidArea(new Dimension(0,10)));
		inputPanel.add(translateButton);

		radioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,15,5));
		radioPanel.add(textButton);
		radioPanel.add(paraphraseButton);
		radioPanel.add(drsButton);
		radioPanel.add(folButton);

		blPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		blPanel.add(helpButton);
		brPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		brPanel.add(saveButton);
		bottomPanel = new JPanel(new GridLayout(1,2));
		bottomPanel.add(blPanel);
		bottomPanel.add(brPanel);

		outputPanel = new JPanel();
		outputPanel.setBorder(BorderFactory.createCompoundBorder(
                      BorderFactory.createTitledBorder("Output"),
                      BorderFactory.createEmptyBorder(10,10,10,10)));
		outputPanel.setLayout(new BorderLayout());
		outputPanel.add(radioPanel,BorderLayout.PAGE_START);
		outputPanel.add(rulemlScrollPane,BorderLayout.CENTER);
		outputPanel.add(bottomPanel,BorderLayout.PAGE_END);

		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
		mainPanel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		mainPanel.add(inputPanel);
		mainPanel.add(outputPanel);
	}

  /**
	 * Create the JFrame for the GUI.
   */
	private void createFrame()
	{
		//JFrame.setDefaultLookAndFeelDecorated(true);
		translatorFrame = new JFrame("TRANSLATOR: TRANSlator from LAnguage TO Rules");
		translatorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		translatorFrame.getRootPane().setDefaultButton(translateButton);
		translatorFrame.getContentPane().add(mainPanel);
		translatorFrame.pack(); 
		translatorFrame.setLocationRelativeTo(null); // center on screen
	}

	/**
	 * Reactivate translate button and clear output. Called after an exception occurs.
	 */
	private void reset()
	{
		translateButton.setEnabled(true);
		translatorFrame.getRootPane().setCursor(Cursor.getDefaultCursor());
		saveButton.setEnabled(false);
		outputTextArea.setText("");
	}	
	
  /**
   * Display the results of translation (depending of the options selected) in the output JTextArea.
   */	
	private void displayResults()
	{
		String header = "";
		
		if (apeMessages != null) header += apeMessages;
		
		if (rulemlString != null)
		{
			results = rulemlString;
			
			if (textButton.isSelected() && text != null) header += "\nText:\n" + text + "\n";
			if (paraphraseButton.isSelected() && paraphrase != null) header += "\nParaphrase:\n" + paraphrase + "\n";
			if (drsButton.isSelected() && drspp != null) header += "\nDRS:\n" + drspp;
			if (folButton.isSelected() && fol != null) header += "\nFOL:\n" + fol + "\n";
		}
		if (header != "") // there are messages from APE and/or results ...
		{
			if (results != null)
			{
				int splitIndex = results.indexOf('>')+2;
				String xmlDec = results.substring(0,splitIndex);
				results = results.substring(splitIndex);
				results = xmlDec + "\n<!--" + header + "-->\n\n" + results;
			}
			else results = header;
		}

		outputTextArea.setText(results);
		outputTextArea.setCaretPosition(0); // scroll to top
	}
	
	/**
	 * Event handler for radio buttons.
	 */
	private class CheckListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if (rulemlString != null) displayResults();
		}
	}
	
	/**
	 * Event handler for the translate, help and save buttons.
	 */
	private class ButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if (event.getSource() == helpButton) BareBonesBrowserLaunch.openURL(HELP_URL);
			else if (event.getSource() == saveButton)
			{
				if (results == null) return;
					
				int returnVal = fc.showSaveDialog(translatorFrame);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					File file = fc.getSelectedFile();
					BufferedWriter writer;
					try
					{
						// not much luck with encodings... @@@
						writer = new BufferedWriter( new OutputStreamWriter(new FileOutputStream(file), "ISO-8859-1") );
						writer.write(results);
						writer.close();
					}
					catch (FileNotFoundException e)
					{
						String title = "File not found";
						JOptionPane.showMessageDialog(translatorFrame,e.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
						System.err.println(title+": "+e);
						return;
					}
					catch (IOException e)
					{
						String title = "Problem during saving";
						JOptionPane.showMessageDialog(translatorFrame,e.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
						System.err.println(title+": "+e);
						return;
					}

					JOptionPane.showMessageDialog(translatorFrame,"Saved "+file.getName()+" successfully.","Saved",JOptionPane.INFORMATION_MESSAGE);
				}
			}
			else if (event.getSource() == translateButton)
			{
				aceText = inputTextArea.getText().trim();
				outputTextArea.setText("");
				saveButton.setEnabled(false);
				results = null;
				rulemlString = null;
				apeMessages = null;
				text = null;
				paraphrase = null;
				drspp = null;
				fol = null;
	
				if (aceText.length() < 1)
				{
					String message = "Please enter ACE text to translate.";
					String title = "No input";
					JOptionPane.showMessageDialog(translatorFrame,message,title,JOptionPane.ERROR_MESSAGE);
					inputTextArea.requestFocus();
					return;
				}

				if (preprocess() == false) return;

				// disable button to prevent user from hitting repeatedly
				translateButton.setEnabled(false);
				translatorFrame.getRootPane().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				
				outputTextArea.setText("Connecting to APE webservice...");
				
				final String queryString;

				try { queryString = QUERYBASE + PARAMS + URLEncoder.encode(aceText, "UTF-8"); }
				catch (UnsupportedEncodingException uee)
				{
					String title = "Unsupported encoding";
					JOptionPane.showMessageDialog(translatorFrame, uee.getLocalizedMessage(),title, JOptionPane.ERROR_MESSAGE);
					System.err.println(title+": "+uee);
					reset();
					return;
				}

				// read from webservice on a different thread so that the GUI remains responsive
	    	final SwingWorker worker = new SwingWorker()
				{
					Document doc = null;

  	      public Object construct()
					{
						try
						{
							Builder builder = new Builder();
							doc = builder.build(queryString);
						}
						catch (ParsingException ex)
						{
							String title = "Malformed XML from webservice";
							JOptionPane.showMessageDialog(translatorFrame,ex.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
							System.err.println(title+": "+ex);
						}
						catch (IOException ex)
						{
							String title = "Unable to connect to webservice";
							JOptionPane.showMessageDialog(translatorFrame,ex.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
							System.err.println(title+": "+ex);
						}

						return null; // return value not used
					}

					public void finished()
					{
						if (doc == null) { reset(); return; }

						// clear output textarea in preparation for output
						outputTextArea.setText("");

						Element apeResult = doc.getRootElement();
						messageCheck(apeResult.getFirstChildElement("messages"));

						// set instance variables
						String drs = apeResult.getFirstChildElement("drs").getValue();
						if (drs.equals("drs([], [])")) drs = null;
						
						text = apeResult.getFirstChildElement("acetext").getValue();
						if (text.trim().equals("")) text = null;
							
						paraphrase = apeResult.getFirstChildElement("paraphrase").getValue();
						if (paraphrase.trim().equals("")) paraphrase = null;
							
						drspp = apeResult.getFirstChildElement("drspp").getValue();
						if (drspp.equals("No conditions\n[]\n")) drspp = null;
						
						// there may not be an FOL at all, so first check for it
						Element temp = apeResult.getFirstChildElement("fol");
						if (temp != null) fol = temp.getValue();
						
						if (drs != null)
						{
							java.io.Reader r = new java.io.BufferedReader(new java.io.StringReader(drs));
							Element as = null;

							// parse DRS with DRS parser
							try
							{
								if (parser == null) parser = new DRSParser(r);
								else parser.ReInit(r);
								as = parser.Start();
							}
							catch (ParseException e)
							{
								String title = "Problem during parsing";
								JOptionPane.showMessageDialog(translatorFrame,e.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
								System.err.println(title+": "+e);
								reset();
								return;
							}
	
							// build RuleML
							Element root = new Element("RuleML", RULEML_NAMESPACE);
							Attribute schemaloc =
								new Attribute("schemaLocation", RULEML_NAMESPACE + " " + RULEML_XSD);
							schemaloc.setNamespace("xsi", SCHEMA_INSTANCE);
							root.addAttribute(schemaloc);
							Element oid = new Element("oid", RULEML_NAMESPACE);
							Element ind = new Element("Ind", RULEML_NAMESPACE);
							root.appendChild(oid);
							oid.appendChild(ind);
							ind.appendChild("Translated version of ACE text \"" + text + "\"");
							root.appendChild(as);
							Document rulemlDoc = new Document(root);
							
							
							// serialize a RuleML string
							ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
							try
							{
								Serializer ser = new Serializer( new PrintStream( byteArray ), "ISO-8859-1");
								ser.setIndent(3);
								ser.setLineSeparator("\n");
								ser.setMaxLength(70);
								ser.write(rulemlDoc);
								rulemlString = byteArray.toString();
								
								/* use serializer just for its nice line wrapping for text, paraphrase and fol
								Element tempElem = new Element("Temp");
								tempElem.appendChild(fol);
								byteArray = new ByteArrayOutputStream();
								ser = new Serializer( new PrintStream( byteArray ), "ISO-8859-1");
								ser.setLineSeparator("\n");
								ser.setMaxLength(70);
								ser.write(new Document(tempElem));
								fol = byteArray.toString();
								fol = fol.substring(fol.indexOf("<Temp>")+6,fol.indexOf("</Temp>"));
								
								Element tempElem2 = new Element("Temp");
								tempElem2.appendChild(paraphrase);
								byteArray = new ByteArrayOutputStream();
								ser = new Serializer( new PrintStream( byteArray ), "ISO-8859-1");
								ser.setLineSeparator("\n");
								ser.setMaxLength(70);
								ser.write(new Document(tempElem2));
								paraphrase = byteArray.toString();
								paraphrase = paraphrase.substring(paraphrase.indexOf("<Temp>")+6,paraphrase.indexOf("</Temp>"));
								*/
							}
							catch (UnsupportedEncodingException ue)
							{
								String title = "Unsupported encoding";
								JOptionPane.showMessageDialog(translatorFrame,ue.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
								System.err.println(title+": "+ue);
								reset();
								return;
							}
							catch (IOException e)
							{
								String title = "Problem during serialization";
								JOptionPane.showMessageDialog(translatorFrame,e.getLocalizedMessage(),title,JOptionPane.ERROR_MESSAGE);
								System.err.println(title+": "+e);
								reset();
								return;
							}
							saveButton.setEnabled(true);
						}
						displayResults();
						
						translateButton.setEnabled(true);
						translatorFrame.getRootPane().setCursor(Cursor.getDefaultCursor());
	        }

  	  	}; // end worker

  	  	worker.start();
			}
		}
	} // end ButtonListener

	/**
	 * Print out any messages from APE webservice.
	 */
	private void messageCheck(Element messages)
	{
		apeMessages = null;
		if (messages.getChildCount() == 0) return;
		apeMessages = "";
		int k = 0;
		for (int i = 0; i < messages.getChildCount(); i++)
		{
			Node node = messages.getChild(i);
			if (node instanceof Text) continue;
			Element m =	(Element)node;
			apeMessages += "\nMessage "+ ++k + " from APE webservice:\n";
			apeMessages += "Sentence: "+m.getAttribute("sentence").getValue()+"\n";
			apeMessages += "Word: "+m.getAttribute("token").getValue()+"\n";
			apeMessages += "Error: "+m.getAttribute("value").getValue()+"\n";
			apeMessages += "Suggestions: "+m.getAttribute("repair").getValue()+"\n";
		}
		outputTextArea.setText(apeMessages);
	}
	
	/**
	 * Preprocess ACE input text.
	 */
	private boolean preprocess()
	{
		char endChar = aceText.charAt(aceText.length()-1);
		if (endChar == '?')
		{
			String title = "Queries not supported";
			String message = "Queries (ending in '?') are not currently supported.";
			JOptionPane.showMessageDialog(translatorFrame,message,title,JOptionPane.ERROR_MESSAGE);
			inputTextArea.selectAll();
			inputTextArea.requestFocus();
			return false;
		}
		else if (endChar != '.')
		{
			// valid ACE text must end with a period
			aceText += ".";	
		}
		
		// rearrange "Y if X" rules (not valid ACE) to "if X then Y" rules (valid ACE)
		int ifIndex = aceText.indexOf(" if ");
		while (ifIndex != -1)
		{
			int endOfSentence = aceText.indexOf('.',ifIndex);
			// find index where prev sentence ends
			String firstHalf = aceText.substring(0,ifIndex);
			int endOfPrevSentence = firstHalf.lastIndexOf('.');
			if (endOfPrevSentence == -1) endOfPrevSentence = 0;
			else endOfPrevSentence = endOfPrevSentence + 2;
			String original = aceText.substring(endOfPrevSentence,endOfSentence);
			// capitalization may be off, but better than doing nothing
			String head = "then " + aceText.substring(endOfPrevSentence,ifIndex);
			String body = aceText.substring(ifIndex+1,endOfSentence);
			body = body.substring(0,1).toUpperCase() + body.substring(1, body.length());
			String replacement = body + " " + head;
			aceText = aceText.replace(original,replacement);
			ifIndex = aceText.indexOf(" if ");
		}
		
		return true;
	}
	
} // end Translator
